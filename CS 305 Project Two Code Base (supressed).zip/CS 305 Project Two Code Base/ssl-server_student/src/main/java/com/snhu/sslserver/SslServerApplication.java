package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{ 
	// Hash function to encrypt a message of type String
	public static String hashMessage(String message) throws NoSuchAlgorithmException {
		// Message digest object to obtain algorithm
		MessageDigest md  = MessageDigest.getInstance("SHA-256");
		md.update(message.getBytes());
		// convert string to bytes
		byte[] b = md.digest();
		// String buffer to hold hex string
		StringBuffer dm = new StringBuffer();
		
		for(byte b1: b) {
			// Start for loop
			dm.append(Integer.toHexString(b1 & 0xff).toString());
		}
		// End for loop
		return dm.toString();
		
	}
	// Hash function RESTful request route
    @RequestMapping("/hash")
    public String myHash(){
    	String message = "Tyler Thomas";
    	String crypted = null;
    	try { 		
    		crypted = hashMessage(message);
    	}   
    	catch(NoSuchAlgorithmException e) {}
       
        return "data:"+message
        		+ " "
        		+ "<p>"
        		+ "Name of Cipher Algorithm Used: SHA-256 <p>CheckSum Value:" +crypted;
    }
}